const express = require('express');
const Router = express.Router();
const { check, validationResult } = require('express-validator');
const mysqlConnection = require('../../connection');
// authenticateToken can be used locally(on each function) or globally in server for all mod
// const authenticateToken= require('../middleware/authenticateToken');


// Router.get('/all',authenticateToken,  function (req, res) {// with local auth

// used with angular 20221130 with angular-datatable for emp degree
// Search Datatable severside code
// *******************************************************************************************************
    



Router.get('/maxproprofilecodesf330id', function (req, res) {
    // console.log("from maxempid"); 
    mysqlConnection.query("SELECT MAX(ID) as maxproprofilecodesf330id FROM pro_profilecodesf330", (err, result) => {
        if (err) {
            console.log(err)
        }
        res.send(result);
        // res.send(result[0].empid);
    });

});




// EDIT GET
Router.get('/:id',  (req, res) => {
  
    let sql = "SELECT * FROM pro_profilecodesf330 WHERE pro_profilecodesf330.ID=?";

    mysqlConnection.query(sql,req.param("id"), (err, rows, fields) => {
        if (!err) {
            res.send(rows[0]); //NOTE Have to send the [0] row
            console.log(rows[0]);
            // res.render("Hello.ejs", {name:rows});
        } else {
            console.log(err);
        }
    });

})






// DETAIL PAGE used in ANGULAR 2022 to get jobtitle name instead of id
Router.get('/proprofilecodesf330details/:id', async (req, res) => {
    // mysqlConnection.query("SELECT * FROM emp_main WHERE emp_main.empid="+req.param('empid'),(err,rows,fields)=>{
    mysqlConnection.query(

        // `SELECT emp_main.EmployeeID AS disEmployeeID, list_empprojectrole.Str1 AS disEmpProjectRole, list_empprojectrole_1.Str1 AS disSecProjectRole, pro_team.ID, \
        // pro_team.DutiesAndResponsibilities, pro_team.DurationFrom, pro_team.DurationTo, pro_team.MonthsOfExp, pro_team.Notes, pro_team.ProjectID, \ 
        // pro_team.EmpProjectRole, pro_team.SecProjectRole, pro_team.EmpID \
        // FROM pro_team INNER JOIN \
        // emp_main ON pro_team.EmpID = emp_main.EmpID INNER JOIN \
        // list_empprojectrole ON pro_team.EmpProjectRole = list_empprojectrole.ListID INNER JOIN \
        // list_empprojectrole AS list_empprojectrole_1 ON pro_team.SecProjectRole = list_empprojectrole_1.ListID \
        // WHERE pro_team.ID = ?`  ,  

        `SELECT pro_profilecodesf330.ID, pro_profilecodesf330.ProfileCodeSF330, pro_profilecodesf330.ProfileCodeSF330Fee, pro_profilecodesf330.ProjectID,  \
        list_profilecodesf330.Str2 AS disProfileCodeSF330 \
            FROM  pro_profilecodesf330 INNER JOIN \
            list_profilecodesf330 ON pro_profilecodesf330.ProfileCodeSF330 = list_profilecodesf330.ListID \
            WHERE (pro_profilecodesf330.ID = ?)`  ,  
        
     req.param('id'), (err, rows, fields) => {
        if (!err) {
            res.send(rows[0]);
        } else {
            console.log(err);
        }
    });
});






    // UPDATE
    Router.post('/update', [
        // check('degree', "Degree cannot be empty.").notEmpty(),
        check('profilecodesf330', "ProfilecodeSF330 cannot be empty.").isInt({ min:1}),
   
        // check('degree', "Degree cannot be empty.").isInt({ min:1, max: 2000}),
        // check('firstname', "Firstname cannot be empty.").notEmpty()//.isEmail().withMessage('Firstname TEST must contain a number')
    ],
        function (req, res) {
             const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }
    
            let post3 = req.body;
    
            let query = `UPDATE pro_profilecodesf330  SET ? WHERE ID=?`;
            mysqlConnection.query(query, [post3, req.body.id], (err, rows, fields) => {
                if (!err) {
                    res.send(rows);
                    console.log(post3);
                } else {
                    console.log("err");
                }
            });
        });
    
    
    
    
    // INSERT
    // Router.post('/', function (req, res) {
        // With express-Validator   
        Router.post('/',[ 
            check('profilecodesf330', "ProfilecodeSF330 cannot be empty.").isInt({ min:1}),
            ], 
            function (req, res) {
               
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }
    
        let postdata = req.body; 
    
        mysqlConnection.query('INSERT INTO pro_profilecodesf330 SET ?', postdata, function (error, results, fields) {
            if (!error) {
                console.log("success");
                res.send(results);
            } else {
                console.log(error);
            }
        });
    });




    // DELETE pro team
    Router.delete('/:proprofilecodesf330id', function (req, res) {
        mysqlConnection.query("DELETE FROM pro_profilecodesf330 WHERE ID=?", req.param('proprofilecodesf330id'), (err, rows, fields) => {
            if (!err) {
                res.send(rows);
            } else {
                console.log(err);
            }
        });
    });





// Router.post('/search/angular-datatable',authenticateToken, function (req, res) { // with local auth
// Router.post('/empdegree-angular-datatable/:empid', function (req, res) {
    Router.post('/proprofilecode-angular-datatable', function (req, res) { // sending empid in body now

        // console.log(req.body);
        // return;

        let draw = req.body.draw;
        let limit = req.body.length;
        let offset = req.body.start;
        // let ordercol = req.body['order[0][column]'];
        let ordercol = req.body.order[0].column;//changed 20221130 for angular
        // let orderdir =  req.body['order[0][dir]'];
        let orderdir = req.body.order[0].dir;//changed 20221130 for angular
        let search = req.body.search.value;
        // let search = req.body['search[value]'];
      
    
        // to get the column name from index since dtable sends col index
        var columns = {
            0: 'ProfileCodeSF330',
            1: 'ProfileCodeSF330Fee',
                
         }
    
        var totalData = 0;
        var totalbeforefilter = 0;
        var totalFiltered = 0;
        var col = columns[ordercol];// to get name of order col not index
    
        // For Getting the TotalData without Filter
        // let sql1 = `SELECT * FROM pro_profilecodesf330 WHERE pro_profilecodesf330.ID>0`;
        let sql1 = `SELECT * FROM pro_profilecodesf330 WHERE pro_profilecodesf330.ProjectID=`+ req.body.projectid + ``;//2023

        mysqlConnection.query(sql1, (err, rows, fields) => {
            totalData = rows.length;
            totalbeforefilter = rows.length;
        });
     
        let sql = 

        // `SELECT pro_profilecodesf330.ID, pro_profilecodesf330.ProfileCodeSF330, pro_profilecodesf330.ProfileCodeSF330Fee, pro_profilecodesf330.ProjectID, 
        // list_profilecodesf330.Str1 + N' : ' + list_profilecodesf330.Str2 AS disProfileCodeSF330
        //     FROM  pro_profilecodesf330 INNER JOIN
        //     list_profilecodesf330 ON pro_profilecodesf330.ProfileCodeSF330 = list_profilecodesf330.ListID
        //     WHERE (pro_profilecodesf330.ProjectID = `+ req.body.projectid + `)`

        `SELECT pro_profilecodesf330.ID, pro_profilecodesf330.ProfileCodeSF330, pro_profilecodesf330.ProfileCodeSF330Fee, pro_profilecodesf330.ProjectID, 
        list_profilecodesf330.Str2 AS disProfileCodeSF330
            FROM  pro_profilecodesf330 INNER JOIN
            list_profilecodesf330 ON pro_profilecodesf330.ProfileCodeSF330 = list_profilecodesf330.ListID
            WHERE (pro_profilecodesf330.ProjectID = `+ req.body.projectid + `)`



        if (search == "") {
            // console.log("No Search");
            sql = sql + ` order by ${col} ${orderdir} limit ${limit} offset ${offset} `;
            // console.log("mysql "+sql);
            mysqlConnection.query(sql, (err, rows, fields) => {
                
                if (!err) {
                    // totalFiltered = rows.length; //totalbeforefilter
                    totalFiltered = totalData; //totalbeforefilter
                    res.json({
                        "draw": draw,
                        "recordsTotal": totalData, //totalData,
                        "recordsFiltered": totalFiltered,
                        "data": rows
                    });
                }
                else {
                    console.log(err);
                }

                // if (!err) {

                //     if (!filterpresent) {
                //         totalFiltered = totalbeforefilter;
                //     }
                //     else{
                //         totalFiltered = rows.length;
                //     }
                //     res.json({
                //         "draw": draw,
                //         "recordsTotal": totalData,
                //         "recordsFiltered": totalFiltered,
                //         "data": rows
                //     });
                // }
                // else {
                //     console.log(err);
                // }

            });
    
        } else {
            // console.log(sql);
            sql = sql + ` AND list_profilecodesf330.Str1 LIKE '%${search}%'`;

            // //2023 important. When limit and offset is used to sql string then total length always shows the "limit"
            // So total filtered record is calculated before applying limit and
            let totalbeforelimitandoffset = 0;
            let sql3 = sql + ` order by ${col} ${orderdir} `;
            mysqlConnection.query(sql3, (err, rows3, fields) => {
                totalbeforelimitandoffset = rows3.length;
                // console.log("testtotal :: " + sql3);
            });


            mysqlConnection.query(sql, (err, rows, fields) => {
                if (!err) {
                    // totalFiltered = rows.length
                    totalFiltered = totalbeforelimitandoffset
                    res.json({
                        "draw": draw,
                        "recordsTotal": totalData, //totalData,
                        "recordsFiltered": totalFiltered,
                        "data": rows
                    });
                }
                else {
                    console.log(err);
                }
                
            });
    
        } // end else
    });
    













// // VIEW 1 RECORD
// Router.get('/view/:id', async (req, res) => {
//     try {
//         let id = req.param("id");

//         let strsql=
//         `SELECT Pro_ProfileCodeSF330.ID, Pro_ProfileCodeSF330.ProfileCodeSF330, Pro_ProfileCodeSF330.ProfileCodeSF330Fee, Pro_ProfileCodeSF330.ProjectID, 
//         List_ProfileCodeSF330.Str1 + N' : ' + List_ProfileCodeSF330.Str2 AS disProfileCodeSF330
//         FROM  Pro_ProfileCodeSF330 INNER JOIN
//         List_ProfileCodeSF330 ON Pro_ProfileCodeSF330.ProfileCodeSF330 = List_ProfileCodeSF330.ListID
//         WHERE (Pro_ProfileCodeSF330.ID = ${id})`

//         let pool = await sql.connect(mssqlconfig)
//         //let pool = await poolPromise
//         let result = await pool.request()
//             // .query(`SELECT emp_degree.empid, list_empdegree.str1 FROM emp_degree INNER JOIN list_empdegree ON emp_degree.degree=list_empdegree.listid WHERE emp_degree.empid=${empid}`)
//             .query(strsql);
//             res.send(result.recordset[0]);
//     } catch (err) {
//         return res.status(400).send("MSSQL ERROR: " + err);
//     }
// })




module.exports = Router;